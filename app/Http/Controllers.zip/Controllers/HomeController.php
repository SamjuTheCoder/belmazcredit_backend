<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/*
 * @Author: Julius Fasema
 * Controller: HomeController
 * Description: Defines all the functions for registration.
 * Date: 30-01-2022
 */

class HomeController extends FunctionsController
{
    // user dashboard
     public function UserDashboard() {
        
        $data = $this->home(Auth::user()->phases_id, Auth::user()->referral_id); // call user dashboard function

        return response()->json([
            'success' => 'success',
            'code'    => '00',
            'message' => 'User Dashboard successfully loaded!',
            'data' => $data,
        ]);
    }

    // admin dashboard
    public function AdminDashboard() {
        
        $data = $this->adminHome(Auth::user()->id ); // call user dashboard function

        return response()->json([
            'success' => 'success',
            'code'    => '00',
            'message' => 'Admin Dashboard successfully loaded!',
            'data' => $data,
        ]);
    }


    // users dashboard
    public function home($user_phase, $user_referralid) {

        $count = 0;
        $phase2users = [];

        $user_role = $this->getUserRole(Auth::user()->id);
        
        $users = $this->getMyUser($user_referralid);
        $users2 = $this->UsersPhase2($user_referralid);
        $users3 = $this->UsersPhase3($user_referralid);
        $users4 = $this->UsersPhase4($user_referralid);

        //count users in each stage
        $count1 = $this->validateNumberOfUsersPhase1($user_referralid);
        $count2 = $this->validateNumberOfUsersPhase2($user_referralid);
        $count3 = $this->validateNumberOfUsersPhase3($user_referralid);
        $count4 = $this->validateNumberOfUsersPhase4($user_referralid);

        // call users stage amount
        $phase_amount = $this->getPhaseAmount(Auth::user()->id);

        // call investment setup
        $investment = $this->getInvestmentAmount(Auth::user()->id, Auth::user()->investment_id );

        // get loan amount
        $loan = $this->getLoanAmount(Auth::user()->phases_id);

        // call my loan amount function
        $myloan = $this->getMyLoanAmount(Auth::user()->phases_id, Auth::user()->id);
        
        // get refferal count
        $referral_count = $this->getBonusCount(Auth::user()->referral_id);

         // get total referral amount
         $total_referral_amount = $this->getBonus(Auth::user()->referral_id);

         // get total investment amount
         $investment_amount = $this->getTotalInvestmentAmount(Auth::user()->id);

        // check if user is in phase 1 - 10users
        if( $user_phase == 1 ) {

            foreach( $users as $user ) {

                $count = $this->validateNumberOfUsersPhase1($user->referral_id); // check if each user has 10
                $phase1Users = $this->UsersPhase1($user->referral_id);

                $count += $count; 
                array_push($phase2users, $phase1Users);

                if($count == 10 ) { 

                    $this->updateUserPhase(2,$user_referralid);

                    foreach($phase1Users as $pusers) {
                        $this->addUsersPhase2($pusers->referral_id, $user_referralid);
                    }

                }

            }

            return [
                "stage_users" => $count1,
                "user_phase"=> Auth::user()->phases_id,
                "user_referral_id"=>Auth::user()->referral_id,
                'phase_amount' => $phase_amount,
                'investment' => $investment,
                'loan' => $loan,
                'myloan' => $myloan,
                'referral_count' => $referral_count,
                'total_referral_amount' => $total_referral_amount,
                'investment_amount' => $investment_amount,
                'user_role' => $user_role
                ];


        } // end phase 1 check

        // check if user is in phase 2- 100
        elseif( $user_phase == 2 ) {

            foreach( $users2 as $user ) {

                $users = $this->getMyUser($user->referral_id);
                array_push($phase2users, $users);
                   
                    foreach($users as $pusers) {

                        $count ++; 

                        if ( $count == 100 ) { 
                        $this->updateUserPhase(3,$user_referralid); 
                        $this->addUsersPhase3($pusers->referral_id, $user_referralid);
                    }
                }

            }

            return [
                "stage_users" => $count2,
                "user_phase"=>Auth::user()->phases_id,
                "user_referral_id"=>Auth::user()->referral_id,
                'phase_amount' => $phase_amount, 
                'investment' => $investment,
                'loan' => $loan,
                'myloan' => $myloan,
                'referral_count' => $referral_count,
                'total_referral_amount' => $total_referral_amount,
                'investment_amount' => $investment_amount,
                'user_role' => $user_role
                ];

        } // end phase 2 check

        // check if user is in phase 3 - 1000
        elseif( $user_phase == 3 ) {

            foreach( $users3 as $user ) {

                $users = $this->getMyUser($user->referral_id);

                array_push($phase2users, $users);
                   
                    foreach($users as $pusers) {

                        $count ++; 

                        if ( $count == 1000 ) { 
                        $this->updateUserPhase(4,$user_referralid); 
                        $this->addUsersPhase4($pusers->referral_id, $user_referralid);
                    }
                }

            }

            return [
                "stage_users" => $count3,
                "user_phase"=>Auth::user()->phases_id,
                "user_referral_id"=>Auth::user()->referral_id,
                'phase_amount' => $phase_amount,
                'investment' => $investment,
                'loan' => $loan,
                'myloan' => $myloan,
                'referral_count' => $referral_count,
                'total_referral_amount' => $total_referral_amount,
                'investment_amount' => $investment_amount,
                'user_role' => $user_role
                ];

        } // end phase 3 check

        // check if user is in stage 4 - 10000
        elseif( $user_phase == 4 ) {

            foreach( $users4 as $user ) {

                $users = $this->getMyUser($user->referral_id);
                array_push($phase2users, $users);
                   
                    foreach($users as $pusers) {

                        $count ++; 

                        if ( $count == 10000 ) { 
                        $this->updateUserPhase(1,$user_referralid); 
                    }
                }

            }

            return [
                "stage_users" => $count4,
                "user_phase"=> Auth::user()->phases_id,
                "user_referral_id"=> Auth::user()->referral_id,
                'phase_amount' => $phase_amount,
                'investment' => $investment,
                'loan' => $loan, 
                'myloan' => $myloan,
                'referral_count' => $referral_count,
                'total_referral_amount' => $total_referral_amount,
                'investment_amount' => $investment_amount,
                'user_role' => $user_role
                ];

        } // end phase 4 check

    } // end users dashboard


    // admin dashboard
    public function adminHome($user_id) {

        $count = 0;
        $phase2users = [];

        // call total contributors
        $total_contributors = $this->totalContributors();
        
        // call total contributions
        $total_contributions = $this->totalContributions();

        // call total referral
        $total_referral = $this->totalReferral();

        // call referral amount
        $total_referral_amount = $this->totalReferralAmount();

        // call total investment
        $total_investment = $this->totalInvestment();
        
        // get refferal count
        $total_loans = $this->totalLoans();

        // get total referral amount
        $total_loan_interest = $this->totalLoansInterest();

      
        return [
            "total_contributors" => $total_contributors,
            "total_contributions"=> $total_contributions,
            "total_referral"=> $total_referral,
            'total_referral_amount' => $total_referral_amount,
            'total_investment' => $total_investment,
            'total_loans' => $total_loans,
            'total_loan_interest' => $total_loan_interest,
            ];

        
    }// end admin dashboard

    //list contributors
    public function listContributors() {

        $list_contributors = $this->listContributor();


        return [
            'list_contributors' => $list_contributors
            ];
    }

     //list contributors loan 
     public function listContributorsLoans() {

        $list_contributors_loan = $this->listContributorLoan();


        return [
            'list_contributors_loan' => $list_contributors_loan
            ];
    }

     //list all investment 
     public function listAllInvestment() {

        $list_investment = $this->listAllInvestments();


        return [
            'list_investment' => $list_investment
            ];
    }

    //list all investment 
    public function sumAllWallets() {

        $list_all = $this->sumAllWallet();


        return [
            'list_wallets' => $list_all
            ];
    }

       

    
}

